<?php

/**
 * @file
 */
namespace Drupal\coucou\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Creates a 'coucou' Block
 * @Block(
 * id = "block_coucou",
 * admin_label = @Translation("Coucou block"),
 * )
 */
class CoucouBlock extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
        return array (
            '#type' => 'markup',
            '#markup' => '<h2>Coucou</h2>',
        );
    }

}

?>
