<?php

/**
 * @file
 */
namespace Drupal\coucou\Plugin\Block;

use Drupal\Core\Block\BlockBase;

// Use the namespace of the ExampleEvent class
use Drupal\example_events\ExampleEvent;

/**
 * Creates a 'coucou' Block
 * @Block(
 * id = "block_coucou",
 * admin_label = @Translation("Coucou block"),
 * )
 */
class CoucouBlock extends BlockBase {

    /**
     * {@inheritdoc}
     */
    public function build() {
	\Drupal::messenger()->addMessage('Say something else 1');


// Load dispatcher object through services.
$dispatcher = \Drupal::service('event_dispatcher');
// creating our event class object.
$event = new ExampleEvent("My Event");
// Dispatching the event through the ‘dispatch’  method,
// Passing event name and event object ‘$event’ as parameters.
$dispatcher->dispatch(ExampleEvent::RUN, $event);

        return array (
            '#type' => 'markup',
            '#markup' => '<h2>Coucou '.time().'</h2>',
            '#cache' => array(
                   'max-age' => 0,
            ), 
        );
    }

}

?>
