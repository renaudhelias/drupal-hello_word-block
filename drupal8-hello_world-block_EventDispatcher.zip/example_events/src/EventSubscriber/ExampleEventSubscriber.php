<?php
/**
 * @file
 * Contains \Drupal\example_events\ExampleEventSubscriber.
 */
namespace Drupal\example_events\EventSubscriber;
//use Drupal\Core\Config\ConfigCrudEvent;
//use Drupal\Core\Config\ConfigEvents;
use Drupal\example_events\ExampleEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
/**
 * Class ExampleEventSubscriber.
 *
 * @package Drupal\example_events
 */
class ExampleEventSubscriber implements EventSubscriberInterface {
  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    // Priority greater than 200 = No Cache (like hook_boot).
    $events[ExampleEvent::RUN][] = array('doSomeAction', 300);
    return $events;
  }
  /**
   * Subscriber Callback for the event.
   * @param ExampleEvent $event
   */
  public function doSomeAction(ExampleEvent $event) {
    // Get data:
    $data = $event->getData();
    \Drupal::messenger()->addMessage("The Example Event has been subscribed, event->getData() returned : '" . $event->getData() . "'");
    // Run display() action.
    $event->display();
  }
}

?>
