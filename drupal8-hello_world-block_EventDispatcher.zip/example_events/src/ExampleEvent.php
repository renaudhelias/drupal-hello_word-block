<?php
namespace Drupal\example_events;
use Symfony\Component\EventDispatcher\Event;
class ExampleEvent extends Event {
  const RUN = 'event.run';
  protected $data;
  public function __construct($data) {
    $this->data = $data;
  }
  public function getData() {
    return $this->data;
  }
  public function display() {
    \Drupal::messenger()->addMessage("This is as an example event : ".$this->data);
  }
}

?>
